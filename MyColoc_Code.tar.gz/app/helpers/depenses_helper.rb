module DepensesHelper
end

# -*- encoding : utf-8 -*-
# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MyColoc::Application.config.secret_token = 'ecf1cdd3a37e5dee8afa89e1159006339d1164297f2b348b1f8e5e5d368f3536ff137a03b87daaa163a1ecb16239e3a45c5468898d32bba0e0ec59dde1f005a0'
